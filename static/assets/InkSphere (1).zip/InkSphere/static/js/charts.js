// Function to load and display analytics charts
function loadAnalyticsCharts() {
    // Fetch analytics data from the server
    fetch('/analytics/data')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Update statistics counters
            document.getElementById('total-posts').textContent = data.counts.total_posts;
            document.getElementById('total-users').textContent = data.counts.total_users;
            document.getElementById('total-views').textContent = data.counts.total_views;
            document.getElementById('highest-seo').textContent = data.seo.highest;
            document.getElementById('lowest-seo').textContent = data.seo.lowest;
            document.getElementById('average-seo').textContent = data.seo.average;
            
            // Blog Post Views Chart - Line Chart
            const viewsCtx = document.getElementById('viewsChart').getContext('2d');
            const viewsChart = new Chart(viewsCtx, {
                type: 'line',
                data: {
                    labels: data.charts.views.labels,
                    datasets: [{
                        label: 'Blog Post Views',
                        data: data.charts.views.data,
                        backgroundColor: 'rgba(78, 66, 212, 0.2)',
                        borderColor: 'rgba(78, 66, 212, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        pointBackgroundColor: 'rgba(78, 66, 212, 1)',
                        pointBorderColor: '#fff',
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            backgroundColor: 'rgba(0, 0, 0, 0.7)',
                            titleColor: '#fff',
                            bodyColor: '#fff',
                            titleFont: {
                                size: 14,
                                weight: 'bold'
                            },
                            bodyFont: {
                                size: 14
                            },
                            padding: 10,
                            displayColors: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
            
            // New Users Per Week - Bar Chart
            const usersCtx = document.getElementById('usersChart').getContext('2d');
            const usersChart = new Chart(usersCtx, {
                type: 'bar',
                data: {
                    labels: data.charts.users.labels,
                    datasets: [{
                        label: 'New Users',
                        data: data.charts.users.data,
                        backgroundColor: 'rgba(40, 167, 69, 0.7)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
            
            // Post Status Distribution - Pie Chart
            const statusCtx = document.getElementById('statusChart').getContext('2d');
            const statusChart = new Chart(statusCtx, {
                type: 'pie',
                data: {
                    labels: data.charts.post_status.labels,
                    datasets: [{
                        data: data.charts.post_status.data,
                        backgroundColor: [
                            'rgba(40, 167, 69, 0.7)',  // Published - Green
                            'rgba(255, 193, 7, 0.7)'   // Draft - Yellow
                        ],
                        borderColor: [
                            'rgba(40, 167, 69, 1)',
                            'rgba(255, 193, 7, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
            
            // SEO Rating Distribution - Bar Chart
            const seoDistCtx = document.getElementById('seoDistributionChart').getContext('2d');
            const seoDistChart = new Chart(seoDistCtx, {
                type: 'bar',
                data: {
                    labels: data.charts.seo_distribution.labels,
                    datasets: [{
                        label: 'Number of Posts',
                        data: data.charts.seo_distribution.data,
                        backgroundColor: function(context) {
                            const index = context.dataIndex;
                            const value = context.dataset.data[index];
                            const label = context.chart.data.labels[index];
                            
                            if (label <= 3) return 'rgba(220, 53, 69, 0.7)';      // Red
                            if (label <= 6) return 'rgba(255, 193, 7, 0.7)';      // Yellow
                            return 'rgba(40, 167, 69, 0.7)';                      // Green
                        },
                        borderColor: function(context) {
                            const index = context.dataIndex;
                            const value = context.dataset.data[index];
                            const label = context.chart.data.labels[index];
                            
                            if (label <= 3) return 'rgba(220, 53, 69, 1)';       // Red
                            if (label <= 6) return 'rgba(255, 193, 7, 1)';       // Yellow
                            return 'rgba(40, 167, 69, 1)';                       // Green
                        },
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                title: function(tooltipItems) {
                                    return `SEO Rating: ${tooltipItems[0].label}`;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'SEO Rating'
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Posts'
                            },
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error fetching analytics data:', error);
            document.getElementById('chartsErrorMessage').classList.remove('d-none');
        });
}

// Initialize charts when the page loads if we're on the analytics page
document.addEventListener('DOMContentLoaded', function() {
    const analyticsPage = document.getElementById('analyticsPage');
    if (analyticsPage) {
        loadAnalyticsCharts();
    }
});
