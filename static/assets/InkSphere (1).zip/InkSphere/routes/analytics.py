from flask import Blueprint, render_template, jsonify, request
from app import db
from models import Post, User, PostView
from routes.auth import admin_required
from sqlalchemy import func, desc
import datetime

analytics_bp = Blueprint('analytics', __name__, url_prefix='/analytics')

@analytics_bp.route('/')
@admin_required
def index():
    return render_template('admin/analytics.html')

@analytics_bp.route('/data')
@admin_required
def analytics_data():
    # Get basic counts
    total_posts = Post.query.count()
    total_users = User.query.count()
    published_posts = Post.query.filter_by(status='published').count()
    draft_posts = Post.query.filter_by(status='draft').count()
    
    # Calculate total views
    total_views = db.session.query(func.sum(Post.views)).scalar() or 0
    
    # Get SEO ratings
    posts_with_ratings = Post.query.filter(Post.seo_rating > 0).all()
    if posts_with_ratings:
        highest_seo = max(posts_with_ratings, key=lambda x: x.seo_rating).seo_rating
        lowest_seo = min(posts_with_ratings, key=lambda x: x.seo_rating).seo_rating
        avg_seo = sum(post.seo_rating for post in posts_with_ratings) / len(posts_with_ratings)
    else:
        highest_seo = lowest_seo = avg_seo = 0
    
    # Get view data for the past 30 days
    thirty_days_ago = datetime.datetime.now() - datetime.timedelta(days=30)
    view_data = db.session.query(
        func.date(PostView.timestamp).label('date'),
        func.count(PostView.id).label('views')
    ).filter(PostView.timestamp >= thirty_days_ago)\
     .group_by(func.date(PostView.timestamp))\
     .order_by(func.date(PostView.timestamp))\
     .all()
    
    view_dates = [str(row.date) for row in view_data]
    view_counts = [row.views for row in view_data]
    
    # Get new user registrations by week for the past 4 weeks
    four_weeks_ago = datetime.datetime.now() - datetime.timedelta(weeks=4)
    user_data = db.session.query(
        func.extract('week', User.registration_date).label('week'),
        func.count(User.id).label('count')
    ).filter(User.registration_date >= four_weeks_ago)\
     .group_by(func.extract('week', User.registration_date))\
     .order_by(func.extract('week', User.registration_date))\
     .all()
    
    user_weeks = [f"Week {row.week}" for row in user_data]
    user_counts = [row.count for row in user_data]
    
    # Get SEO rating distribution
    seo_distribution = [0] * 11  # For ratings 0-10
    for post in posts_with_ratings:
        seo_distribution[post.seo_rating] += 1
    
    # Prepare the response data
    data = {
        'counts': {
            'total_posts': total_posts,
            'total_users': total_users,
            'total_views': total_views,
            'published_posts': published_posts,
            'draft_posts': draft_posts
        },
        'seo': {
            'highest': highest_seo,
            'lowest': lowest_seo,
            'average': round(avg_seo, 1)
        },
        'charts': {
            'views': {
                'labels': view_dates,
                'data': view_counts
            },
            'users': {
                'labels': user_weeks,
                'data': user_counts
            },
            'post_status': {
                'labels': ['Published', 'Draft'],
                'data': [published_posts, draft_posts]
            },
            'seo_distribution': {
                'labels': list(range(11)),  # 0-10
                'data': seo_distribution
            }
        }
    }
    
    return jsonify(data)
