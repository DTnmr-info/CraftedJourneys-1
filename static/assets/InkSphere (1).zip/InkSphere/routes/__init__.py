# This file is intentionally left empty to mark the routes directory as a Python package
