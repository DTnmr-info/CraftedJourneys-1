from flask import session, redirect, url_for, flash
from functools import wraps
from models import User

def is_logged_in():
    """Check if a user is logged in"""
    return 'user_id' in session

def get_current_user():
    """Get the current logged in user"""
    if 'user_id' in session:
        user_id = session['user_id']
        return User.query.get(user_id)
    return None

def is_admin():
    """Check if the current user is an admin"""
    user = get_current_user()
    return user and user.role == 'admin'

# Decorator functions are moved to routes/auth.py
