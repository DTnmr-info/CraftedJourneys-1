"""
Social media sharing utilities for TotalEnc blog platform
"""

def get_share_urls(title, url, description=None, tags=None):
    """
    Generate share URLs for various social media platforms
    
    Args:
        title (str): The title of the content being shared
        url (str): The URL of the content being shared
        description (str, optional): A brief description of the content
        tags (list, optional): Tags related to the content
    
    Returns:
        dict: Dictionary of share URLs for different platforms
    """
    # Format tags for Twitter
    hashtags = ""
    if tags:
        tag_list = [tag.strip() for tag in tags.split(',')]
        hashtags = "%20".join([f"#{tag.replace(' ', '')}" for tag in tag_list if tag])
    
    # Create share URLs
    share_urls = {
        'facebook': f"https://www.facebook.com/sharer/sharer.php?u={url}",
        'twitter': f"https://twitter.com/intent/tweet?text={title}&url={url}&hashtags={hashtags}",
        'linkedin': f"https://www.linkedin.com/sharing/share-offsite/?url={url}",
        'pinterest': f"https://pinterest.com/pin/create/button/?url={url}&description={title}",
        'reddit': f"https://www.reddit.com/submit?url={url}&title={title}",
        'whatsapp': f"https://api.whatsapp.com/send?text={title}%20{url}",
        'telegram': f"https://t.me/share/url?url={url}&text={title}",
        'email': f"mailto:?subject={title}&body=Check%20out%20this%20article:%20{url}"
    }
    
    return share_urls