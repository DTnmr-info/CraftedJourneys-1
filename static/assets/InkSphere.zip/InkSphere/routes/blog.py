from flask import Blueprint, render_template, request, redirect, url_for, abort
from flask_login import current_user
from app import db
from models import Post, User, PostView
from sqlalchemy import desc
import datetime
from utils.sharing import get_share_urls

blog_bp = Blueprint('blog', __name__)

@blog_bp.route('/')
def index():
    page = request.args.get('page', 1, type=int)
    per_page = 5  # Number of posts per page
    
    # Query published posts with pagination
    posts = Post.query.filter_by(status='published')\
                     .order_by(desc(Post.created))\
                     .paginate(page=page, per_page=per_page, error_out=False)
    
    # Generate sharing URLs for each post
    post_list = posts.items
    for post in post_list:
        # Create the post URL
        post_url = url_for('blog.view_post', post_id=post.id, _external=True)
        
        # Get sharing URLs for each post
        post.share_urls = get_share_urls(
            title=post.title,
            url=post_url,
            description=post.get_excerpt(),
            tags=post.tags
        )
    
    return render_template('index.html', posts=posts)

@blog_bp.route('/post/<int:post_id>')
def view_post(post_id):
    post = Post.query.get_or_404(post_id)
    
    # If the post is a draft, only the author or an admin can view it
    if post.status == 'draft':
        if not current_user.is_authenticated:
            abort(403)  # Forbidden
        
        if post.user_id != current_user.id and not current_user.is_admin():
            abort(403)  # Forbidden
    
    # Record the view
    record_view(post)
    
    # Get the author's username
    author = User.query.get(post.user_id)
    author_name = author.username if author else "Unknown"
    
    # Generate post URL for sharing
    post_url = request.url
    
    # Get sharing URLs
    share_urls = get_share_urls(
        title=post.title,
        url=post_url,
        description=post.get_excerpt(),
        tags=post.tags
    )
    
    return render_template('post.html', post=post, author_name=author_name, share_urls=share_urls)

def record_view(post):
    """Record a view for analytics purposes"""
    # Increment the view counter
    post.views += 1
    
    # Create a PostView record for detailed analytics
    view = PostView(
        post_id=post.id,
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string
    )
    
    db.session.add(view)
    db.session.commit()
