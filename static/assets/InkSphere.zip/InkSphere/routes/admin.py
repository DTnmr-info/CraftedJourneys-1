from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user
from app import db
from models import User, Post, UserQuery, Message
from routes.auth import admin_required
from sqlalchemy import desc, func
import json

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    # Get counts for dashboard
    total_posts = Post.query.count()
    published_posts = Post.query.filter_by(status='published').count()
    draft_posts = Post.query.filter_by(status='draft').count()
    total_users = User.query.count()
    admin_users = User.query.filter_by(role='admin').count()
    regular_users = total_users - admin_users
    open_queries = UserQuery.query.filter_by(status='open').count()
    
    # Recent posts
    recent_posts = Post.query.order_by(desc(Post.created)).limit(5).all()
    
    # Recent users
    recent_users = User.query.order_by(desc(User.registration_date)).limit(5).all()
    
    return render_template('admin/dashboard.html',
                          total_posts=total_posts,
                          published_posts=published_posts,
                          draft_posts=draft_posts,
                          total_users=total_users,
                          admin_users=admin_users,
                          regular_users=regular_users,
                          open_queries=open_queries,
                          recent_posts=recent_posts,
                          recent_users=recent_users)

@admin_bp.route('/blog_management')
@admin_required
def blog_management():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    # Get filter and sort parameters
    status_filter = request.args.get('status', 'all')
    author_filter = request.args.get('author', 'all')
    sort_by = request.args.get('sort_by', 'created')
    sort_order = request.args.get('sort_order', 'desc')
    
    # Build query
    query = Post.query
    
    # Apply filters
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    if author_filter != 'all':
        query = query.filter_by(user_id=author_filter)
    
    # Apply sorting
    if sort_order == 'desc':
        query = query.order_by(desc(getattr(Post, sort_by)))
    else:
        query = query.order_by(getattr(Post, sort_by))
    
    # Paginate results
    posts = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Get all authors for the filter dropdown
    authors = User.query.all()
    
    return render_template('admin/blog_management.html', 
                          posts=posts,
                          authors=authors,
                          status_filter=status_filter,
                          author_filter=author_filter,
                          sort_by=sort_by,
                          sort_order=sort_order)

@admin_bp.route('/user_management')
@admin_required
def user_management():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    # Get users with post count
    users_with_post_count = db.session.query(
        User,
        func.count(Post.id).label('post_count')
    ).outerjoin(Post).group_by(User.id).paginate(page=page, per_page=per_page)
    
    return render_template('admin/user_management.html', users=users_with_post_count)

@admin_bp.route('/toggle_user_status/<int:user_id>', methods=['POST'])
@admin_required
def toggle_user_status(user_id):
    user = User.query.get_or_404(user_id)
    
    # Prevent self-deactivation
    if user.id == current_user.id:
        flash('You cannot deactivate your own account!', 'danger')
        return redirect(url_for('admin.user_management'))
    
    user.active = not user.active
    db.session.commit()
    
    action = 'enabled' if user.active else 'disabled'
    flash(f'User account {user.username} has been {action}.', 'success')
    
    return redirect(url_for('admin.user_management'))

@admin_bp.route('/view_user/<int:user_id>')
@admin_required
def view_user(user_id):
    user = User.query.get_or_404(user_id)
    
    # Get user's posts
    posts = Post.query.filter_by(user_id=user_id).order_by(desc(Post.created)).all()
    
    # Get user's queries
    queries = UserQuery.query.filter_by(sender_id=user_id).order_by(desc(UserQuery.timestamp)).all()
    
    return render_template('admin/view_user.html', user=user, posts=posts, queries=queries)

@admin_bp.route('/website_integration')
@admin_required
def website_integration():
    return render_template('admin/website_integration.html')

@admin_bp.route('/query_management')
@admin_required
def query_management():
    # Get all open queries
    open_queries = UserQuery.query.filter_by(status='open').order_by(desc(UserQuery.timestamp)).all()
    
    # Get all closed queries
    closed_queries = UserQuery.query.filter_by(status='closed').order_by(desc(UserQuery.timestamp)).all()
    
    return render_template('admin/query_management.html', 
                          open_queries=open_queries,
                          closed_queries=closed_queries)

@admin_bp.route('/answer_query/<int:query_id>', methods=['POST'])
@admin_required
def answer_query(query_id):
    query = UserQuery.query.get_or_404(query_id)
    answer = request.form.get('answer')
    
    if not answer:
        flash('Answer cannot be empty!', 'danger')
        return redirect(url_for('admin.query_management'))
    
    # Update the query
    query.answer = answer
    query.status = 'closed'
    
    # Create a message to the user
    message = Message(
        sender_id=current_user.id,
        receiver_id=query.sender_id,
        message=f"Answer to your query: {query.query_text}\n\n{answer}"
    )
    
    db.session.add(message)
    db.session.commit()
    
    flash('Query answered successfully!', 'success')
    return redirect(url_for('admin.query_management'))
