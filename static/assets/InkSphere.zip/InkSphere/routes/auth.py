from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from models import User
import functools

auth_bp = Blueprint('auth', __name__)

# Decorator for requiring admin role
def admin_required(view):
    @functools.wraps(view)
    @login_required  # First make sure the user is logged in
    def wrapped_view(**kwargs):
        # Now check if the logged in user is an admin
        if not current_user.is_admin():
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('blog.index'))
        
        return view(**kwargs)
    return wrapped_view

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        error = None
        
        # Form validation
        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        elif password != confirm_password:
            error = 'Passwords do not match.'
        elif User.query.filter_by(username=username).first():
            error = f'User {username} is already registered.'
            
        if error is None:
            new_user = User(username=username)
            new_user.set_password(password)
            
            # Set the first user as admin
            if User.query.count() == 0:
                new_user.role = 'admin'
                
            db.session.add(new_user)
            db.session.commit()
            
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('auth.login'))
        
        flash(error, 'danger')
    
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # If user is already logged in, redirect to appropriate dashboard
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('user.dashboard'))
            
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        error = None
        user = User.query.filter_by(username=username).first()
        
        if user is None:
            error = 'Incorrect username.'
        elif not user.check_password(password):
            error = 'Incorrect password.'
        elif not user.is_active():
            error = 'Account is disabled. Please contact an administrator.'
            
        if error is None:
            # Use Flask-Login to log in the user
            login_user(user)
            
            # Store role in session for easy access in templates
            session['username'] = user.username
            session['role'] = user.role
            
            # Get the next page from the query string if it exists
            next_page = request.args.get('next')
            if not next_page or not next_page.startswith('/'):
                # If no valid next page, redirect to appropriate dashboard based on role
                if user.role == 'admin':
                    next_page = url_for('admin.dashboard')
                else:
                    next_page = url_for('user.dashboard')
                    
            flash('Login successful!', 'success')
            return redirect(next_page)
        
        flash(error, 'danger')
    
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    # Use Flask-Login to log out the user
    logout_user()
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('blog.index'))


