from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, Post, Message, UserQuery
from utils.seo import analyze_seo
from utils.image import allowed_file, save_image
import os

user_bp = Blueprint('user', __name__, url_prefix='/user')

@user_bp.route('/dashboard')
@login_required
def dashboard():
    user_id = current_user.id
    
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Number of posts per page
    
    # Get user's blog posts with pagination
    posts = Post.query.filter_by(user_id=user_id)\
                     .order_by(Post.created.desc())\
                     .paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('user/dashboard.html', posts=posts)

@user_bp.route('/create_blog', methods=['GET', 'POST'])
@login_required
def create_blog():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        status = request.form['status']
        tags = request.form.get('tags', '')
        
        # Validate form data
        if not title or not content:
            flash('Title and content are required!', 'danger')
            return render_template('user/create_blog.html', 
                                  title=title, 
                                  content=content, 
                                  status=status, 
                                  tags=tags)
        
        # Create new post
        post = Post(
            user_id=current_user.id,
            title=title,
            content=content,
            status=status,
            tags=tags
        )
        
        # Handle featured image upload
        if 'featured_image' in request.files:
            file = request.files['featured_image']
            if file and file.filename and allowed_file(file.filename):
                filename = save_image(file)
                post.featured_image = filename
        
        # Perform SEO analysis
        seo_rating, seo_feedback = analyze_seo(title, content, tags)
        post.seo_rating = seo_rating
        post.seo_feedback = seo_feedback
        
        # Save to database
        db.session.add(post)
        db.session.commit()
        
        flash('Blog post created successfully!', 'success')
        return redirect(url_for('user.dashboard'))
    
    return render_template('user/create_blog.html')

@user_bp.route('/edit_blog/<int:post_id>', methods=['GET', 'POST'])
@login_required
def edit_blog(post_id):
    post = Post.query.get_or_404(post_id)
    
    # Ensure the user owns this post
    if post.user_id != current_user.id and current_user.role != 'admin':
        flash('You do not have permission to edit this post.', 'danger')
        return redirect(url_for('user.dashboard'))
    
    if request.method == 'POST':
        post.title = request.form['title']
        post.content = request.form['content']
        post.status = request.form['status']
        post.tags = request.form.get('tags', '')
        
        # Handle featured image upload
        if 'featured_image' in request.files:
            file = request.files['featured_image']
            if file and file.filename and allowed_file(file.filename):
                # Remove old image if it exists
                if post.featured_image:
                    try:
                        old_image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], post.featured_image)
                        if os.path.exists(old_image_path):
                            os.remove(old_image_path)
                    except Exception as e:
                        print(f"Error removing old image: {e}")
                
                filename = save_image(file)
                post.featured_image = filename
        
        # Re-analyze SEO
        seo_rating, seo_feedback = analyze_seo(post.title, post.content, post.tags)
        post.seo_rating = seo_rating
        post.seo_feedback = seo_feedback
        
        db.session.commit()
        flash('Blog post updated successfully!', 'success')
        return redirect(url_for('user.dashboard'))
    
    return render_template('user/edit_blog.html', post=post)

@user_bp.route('/delete_blog/<int:post_id>', methods=['POST'])
@login_required
def delete_blog(post_id):
    post = Post.query.get_or_404(post_id)
    
    # Ensure the user owns this post
    if post.user_id != current_user.id and current_user.role != 'admin':
        flash('You do not have permission to delete this post.', 'danger')
        return redirect(url_for('user.dashboard'))
    
    # Remove the featured image if it exists
    if post.featured_image:
        try:
            image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], post.featured_image)
            if os.path.exists(image_path):
                os.remove(image_path)
        except Exception as e:
            print(f"Error removing image: {e}")
    
    db.session.delete(post)
    db.session.commit()
    
    flash('Blog post deleted successfully!', 'success')
    return redirect(url_for('user.dashboard'))

@user_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = current_user
    
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate form data
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required!', 'danger')
        elif not user.check_password(current_password):
            flash('Current password is incorrect!', 'danger')
        elif new_password != confirm_password:
            flash('New passwords do not match!', 'danger')
        else:
            # Update password
            user.set_password(new_password)
            db.session.commit()
            flash('Password updated successfully!', 'success')
    
    return render_template('user/profile.html', user=user)

@user_bp.route('/communication', methods=['GET', 'POST'])
@login_required
def communication():
    user_id = current_user.id
    
    if request.method == 'POST':
        query_text = request.form.get('query')
        
        if not query_text:
            flash('Query cannot be empty!', 'danger')
        else:
            # Create a new query
            query = UserQuery(
                sender_id=user_id,
                query_text=query_text
            )
            
            db.session.add(query)
            db.session.commit()
            
            flash('Your query has been submitted to the administrators.', 'success')
    
    # Get all queries from this user
    queries = UserQuery.query.filter_by(sender_id=user_id).order_by(UserQuery.timestamp.desc()).all()
    
    # Get all messages where this user is the receiver
    messages = Message.query.filter_by(receiver_id=user_id).order_by(Message.timestamp.desc()).all()
    
    # Mark all unread messages as read
    for message in messages:
        if not message.read:
            message.read = True
    
    db.session.commit()
    
    return render_template('user/communication.html', queries=queries, messages=messages)
