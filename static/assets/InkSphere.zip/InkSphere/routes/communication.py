from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user, login_required
from app import db
from models import User, Message
from routes.auth import admin_required

comm_bp = Blueprint('communication', __name__, url_prefix='/communication')

@comm_bp.route('/send_message', methods=['POST'])
@login_required
def send_message():
    sender_id = current_user.id
    receiver_username = request.form.get('receiver')
    message_text = request.form.get('message')
    
    # Validate input
    if not receiver_username or not message_text:
        flash('Receiver and message are required!', 'danger')
        return redirect(url_for('user.communication'))
    
    # Find the receiver
    receiver = User.query.filter_by(username=receiver_username).first()
    if not receiver:
        flash(f'User {receiver_username} not found!', 'danger')
        return redirect(url_for('user.communication'))
    
    # Create and save the message
    message = Message(
        sender_id=sender_id,
        receiver_id=receiver.id,
        message=message_text
    )
    
    db.session.add(message)
    db.session.commit()
    
    flash('Message sent successfully!', 'success')
    
    # Redirect based on user role
    if current_user.is_admin():
        return redirect(url_for('admin.query_management'))
    else:
        return redirect(url_for('user.communication'))

@comm_bp.route('/admin_message', methods=['POST'])
@admin_required
def admin_message():
    sender_id = current_user.id
    receiver_id = request.form.get('receiver_id')
    message_text = request.form.get('message')
    
    # Validate input
    if not receiver_id or not message_text:
        flash('Receiver and message are required!', 'danger')
        return redirect(url_for('admin.query_management'))
    
    # Find the receiver
    receiver = User.query.get(receiver_id)
    if not receiver:
        flash('User not found!', 'danger')
        return redirect(url_for('admin.query_management'))
    
    # Create and save the message
    message = Message(
        sender_id=sender_id,
        receiver_id=receiver.id,
        message=message_text
    )
    
    db.session.add(message)
    db.session.commit()
    
    flash('Message sent successfully!', 'success')
    return redirect(url_for('admin.query_management'))
