from datetime import datetime
from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(10), nullable=False, default='user')
    registration_date = db.Column(db.DateTime, default=datetime.now)
    active = db.Column(db.Boolean, default=True)
    
    # Relationships
    posts = db.relationship('Post', backref='author', lazy=True)
    sent_messages = db.relationship('Message', 
                                   foreign_keys='Message.sender_id',
                                   backref='sender', lazy=True)
    received_messages = db.relationship('Message', 
                                       foreign_keys='Message.receiver_id',
                                       backref='receiver', lazy=True)
    queries = db.relationship('UserQuery', backref='sender', lazy=True)
    
    def set_password(self, password):
        self.password = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password, password)
    
    def is_admin(self):
        return self.role == 'admin'
    
    def is_active(self):
        return self.active

class Post(db.Model):
    __tablename__ = 'posts'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.String(20), nullable=False, default='draft')
    seo_rating = db.Column(db.Integer, default=0)
    seo_feedback = db.Column(db.Text)
    featured_image = db.Column(db.String(255))
    tags = db.Column(db.String(255))
    views = db.Column(db.Integer, default=0)
    
    def get_excerpt(self, length=200):
        # Remove HTML tags for the excerpt
        import re
        plain_text = re.sub(r'<[^>]*>', '', self.content)
        
        if len(plain_text) <= length:
            return plain_text
        
        return plain_text[:length] + "..."

class Message(db.Model):
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    read = db.Column(db.Boolean, default=False)

class UserQuery(db.Model):
    __tablename__ = 'queries'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    query_text = db.Column(db.Text, nullable=False)  # Changed from query to query_text
    answer = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.String(20), default='open')  # open, closed

class PostView(db.Model):
    __tablename__ = 'post_views'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    post_id = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(255))
    
    post = db.relationship('Post', backref=db.backref('views_data', lazy=True))
