import os
import uuid
from flask import current_app
from werkzeug.utils import secure_filename

# Define allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    """Check if a file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_image(file):
    """
    Save an uploaded image to the uploads directory
    
    Args:
        file: The file from request.files
        
    Returns:
        str: The filename of the saved image
    """
    # Generate a secure filename with a UUID to avoid name collisions
    original_filename = secure_filename(file.filename)
    extension = original_filename.rsplit('.', 1)[1].lower()
    new_filename = f"{uuid.uuid4().hex}.{extension}"
    
    # Save the file
    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], new_filename)
    file.save(file_path)
    
    return new_filename
