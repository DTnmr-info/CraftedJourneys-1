import re

def analyze_seo(title, content, tags=None):
    """
    Analyze a blog post for SEO optimization and return a rating and feedback.
    
    Args:
        title (str): The blog post title
        content (str): The blog post content (HTML)
        tags (str, optional): Comma-separated tags
        
    Returns:
        tuple: (rating, feedback_dict) where rating is an int 0-10 and
               feedback_dict is a dictionary of feedback points
    """
    feedback = {}
    points = 0
    max_points = 0
    
    # Strip HTML tags for content analysis
    clean_content = re.sub(r'<[^>]*>', '', content)
    
    # Title analysis
    title_length = len(title)
    max_points += 2
    if 40 <= title_length <= 60:
        points += 2
        feedback['title_length'] = f"Great! Title length ({title_length} chars) is optimal."
    elif 30 <= title_length < 40 or 60 < title_length <= 70:
        points += 1
        feedback['title_length'] = f"Good. Title length ({title_length} chars) is acceptable but not optimal."
    else:
        feedback['title_length'] = f"Needs improvement. Title length ({title_length} chars) is too {'short' if title_length < 30 else 'long'}."
    
    # Content length analysis
    content_length = len(clean_content)
    max_points += 3
    if content_length >= 1500:
        points += 3
        feedback['content_length'] = f"Excellent! Content length ({content_length} chars) is comprehensive."
    elif content_length >= 1000:
        points += 2
        feedback['content_length'] = f"Good. Content length ({content_length} chars) is substantial."
    elif content_length >= 500:
        points += 1
        feedback['content_length'] = f"Acceptable. Content length ({content_length} chars) is moderate."
    else:
        feedback['content_length'] = f"Needs improvement. Content length ({content_length} chars) is too short."
    
    # Heading analysis
    headings = re.findall(r'<h[1-6][^>]*>.*?</h[1-6]>', content)
    max_points += 2
    if len(headings) >= 3:
        points += 2
        feedback['headings'] = f"Great! Found {len(headings)} headings in your content."
    elif len(headings) >= 1:
        points += 1
        feedback['headings'] = f"Good. Found {len(headings)} headings. Consider adding more."
    else:
        feedback['headings'] = "Needs improvement. No headings found. Add headings to break up content."
    
    # Image analysis
    images = re.findall(r'<img[^>]*>', content)
    alt_texts = re.findall(r'alt="([^"]*)"', content)
    max_points += 2
    if len(images) >= 1:
        points += 1
        feedback['images'] = f"Good. Found {len(images)} images in your content."
        if len(alt_texts) == len(images) and all(alt for alt in alt_texts):
            points += 1
            feedback['alt_text'] = "Excellent! All images have alt text."
        else:
            feedback['alt_text'] = "Needs improvement. Not all images have proper alt text."
    else:
        feedback['images'] = "Consider adding images to enhance your content."
    
    # Tags analysis
    max_points += 1
    if tags and len(tags.strip()) > 0:
        tag_list = [tag.strip() for tag in tags.split(',')]
        if 3 <= len(tag_list) <= 8:
            points += 1
            feedback['tags'] = f"Great! You have an optimal number of tags ({len(tag_list)})."
        elif len(tag_list) < 3:
            feedback['tags'] = f"Consider adding more tags. You currently have {len(tag_list)}."
        else:
            feedback['tags'] = f"You have too many tags ({len(tag_list)}). Consider reducing to 5-8 focused tags."
    else:
        feedback['tags'] = "No tags found. Adding relevant tags can improve discoverability."
    
    # Calculate the final rating (0-10 scale)
    if max_points > 0:
        rating = round((points / max_points) * 10)
    else:
        rating = 0
    
    return rating, feedback
