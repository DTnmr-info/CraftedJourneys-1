document.addEventListener('DOMContentLoaded', function() {
    // Image preview functionality for blog post creation/editing
    const imageInput = document.getElementById('featured_image');
    const previewContainer = document.getElementById('image-preview-container');
    const imagePreview = document.getElementById('image-preview');
    const removeImageBtn = document.getElementById('remove-image-btn');
    
    if (imageInput && previewContainer && imagePreview) {
        // Show or hide the preview container based on existing image
        if (imagePreview.src && !imagePreview.src.endsWith('#')) {
            previewContainer.classList.remove('d-none');
        } else {
            previewContainer.classList.add('d-none');
        }
        
        // Handle file selection
        imageInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                
                // Validate file type
                const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (!validTypes.includes(file.type)) {
                    alert('Please select a valid image file (JPEG, PNG, GIF, or WEBP).');
                    this.value = '';
                    return;
                }
                
                // Validate file size (max 5MB)
                const maxSize = 5 * 1024 * 1024; // 5MB in bytes
                if (file.size > maxSize) {
                    alert('The selected image is too large. Maximum size is 5MB.');
                    this.value = '';
                    return;
                }
                
                // Create preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    previewContainer.classList.remove('d-none');
                    
                    // Add animation
                    imagePreview.style.opacity = '0';
                    setTimeout(() => {
                        imagePreview.style.transition = 'opacity 0.3s ease-in-out';
                        imagePreview.style.opacity = '1';
                    }, 50);
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Remove image button
        if (removeImageBtn) {
            removeImageBtn.addEventListener('click', function() {
                imageInput.value = '';
                imagePreview.src = '#';
                previewContainer.classList.add('d-none');
                
                // If we have a hidden input for tracking image removal
                const removeImageInput = document.getElementById('remove_image');
                if (removeImageInput) {
                    removeImageInput.value = 'true';
                }
            });
        }
    }
    
    // Function to validate image upload
    window.validateImageUpload = function(form) {
        const input = form.querySelector('input[type="file"]');
        if (input && input.files.length > 0) {
            const file = input.files[0];
            
            // Validate file type
            const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('Please select a valid image file (JPEG, PNG, GIF, or WEBP).');
                return false;
            }
            
            // Validate file size (max 5MB)
            const maxSize = 5 * 1024 * 1024; // 5MB in bytes
            if (file.size > maxSize) {
                alert('The selected image is too large. Maximum size is 5MB.');
                return false;
            }
        }
        
        return true;
    };
});
