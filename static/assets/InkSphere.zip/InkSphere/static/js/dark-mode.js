document.addEventListener('DOMContentLoaded', function() {
    // Check for saved user preference
    const darkMode = localStorage.getItem('darkMode');
    const darkModeToggle = document.getElementById('darkModeToggle');
    const darkModeIcon = document.getElementById('darkModeIcon');
    
    // Function to enable dark mode
    const enableDarkMode = () => {
        document.body.classList.add('dark-mode');
        localStorage.setItem('darkMode', 'enabled');
        if (darkModeIcon) {
            darkModeIcon.classList.remove('fa-moon');
            darkModeIcon.classList.add('fa-sun');
        }
    };
    
    // Function to disable dark mode
    const disableDarkMode = () => {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('darkMode', null);
        if (darkModeIcon) {
            darkModeIcon.classList.remove('fa-sun');
            darkModeIcon.classList.add('fa-moon');
        }
    };
    
    // If the user previously enabled dark mode, start with dark mode enabled
    if (darkMode === 'enabled') {
        enableDarkMode();
    }
    
    // When toggle button is clicked
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            // Get current mode
            const darkMode = localStorage.getItem('darkMode');
            
            // Toggle dark mode
            if (darkMode !== 'enabled') {
                enableDarkMode();
            } else {
                disableDarkMode();
            }
            
            // If TinyMCE is active, refresh it to apply dark mode styles
            if (typeof tinymce !== 'undefined') {
                setTimeout(() => {
                    tinymce.activeEditor.execCommand('mceRepaint');
                }, 100);
            }
        });
    }
    
    // Handle system preference changes
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleSystemPreferenceChange = (e) => {
        // Only apply if user hasn't manually set a preference
        if (localStorage.getItem('darkMode') === null) {
            if (e.matches) {
                enableDarkMode();
            } else {
                disableDarkMode();
            }
        }
    };
    
    // Add listener for system preference changes
    prefersDarkScheme.addEventListener('change', handleSystemPreferenceChange);
    
    // Initial check for system preference (if no manual preference)
    if (localStorage.getItem('darkMode') === null && prefersDarkScheme.matches) {
        enableDarkMode();
    }
});
